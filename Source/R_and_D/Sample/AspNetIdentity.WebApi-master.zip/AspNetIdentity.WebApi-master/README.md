Tutorial for Building Simple Membership System using ASP.NET Identity 2.1, ASP.NET Web API, and AngularJS 
===============
Tutorial which will cover how to integrate ASP.NET Identity system with ASP.NET Web API. In this tutorial we'll build a secure HTTP service which acts as back-end for SPA front-end built using AngularJS, it should cover in a simple way different ASP.NET Identity 2.1 features such as: Accounts managements, roles management, email confirmations, change password, roles based authorization, claims based authorization, brute force protection.
